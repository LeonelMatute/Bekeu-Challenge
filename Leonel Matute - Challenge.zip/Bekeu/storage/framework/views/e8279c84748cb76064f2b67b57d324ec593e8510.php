<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <style>
            input,select {
                margin: 10px;
                text-align: center;
                background-color: #ECF0F1;
                border: 2px solid transparent;
                border-radius: 3px;
                font-size: 16px;
                font-weight: 200;
                padding: 10px 0;
                width: 250px;
                transition: border .5s;
            }

        </style>
    </head>
    <body class="antialiased">
        <div class="control-group">
            <form class="formEmail" method="POST" action="/email">
                <?php echo csrf_field(); ?>
                <h1> Leonel Matute - Challenge</h1>
                <input id="email" name="email" type="email" placeholder="Email" class="form-control" size="40" required>
                <br>
                <select id="state" name="state" class="form-control">
                    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <input value='Enviar' type="submit" class="btn btn-primary" style="background-color: black; color: white">
            </form>
        </div>
    </div>
    </body>
</html>
<?php /**PATH D:\Desktop\Proyectos\Bekeu\resources\views/welcome.blade.php ENDPATH**/ ?>