<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <style>
            button {
                margin: 10px;
                text-align: center;
                background-color: #ECF0F1;
                border: 2px solid transparent;
                border-radius: 3px;
                font-size: 16px;
                font-weight: 200;
                padding: 10px 0;
                width: 250px;
                transition: border .5s;
            }

        </style>
    </head>
    <h1> LISTADO DE EMAILS</h1>
    <table class="pack-table" style="text-align: left">
        <tr>
            <th>Email</th>
            <th>Estado</th>
        </tr>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <button style="background-color: black; color: white"><a class="login-link" href="/" style="color: white">Volver</a></button>
</html>
<?php /**PATH D:\Desktop\Proyectos\Bekeu\resources\views/listado.blade.php ENDPATH**/ ?>