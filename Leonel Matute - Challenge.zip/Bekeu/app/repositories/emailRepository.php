<?php

namespace App\repositories;

use Exception;
use Illuminate\Support\Facades\DB;

class emailRepository
{

    public function saveEmail($email,$state){
        try {
                $result = DB::insert("INSERT INTO suscripciones (email, stateID, fecha_creacion) VALUES ('$email',$state,CURRENT_DATE)");
                return $result;
        }
        catch (Exception $e){
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    public function listar()
    {
        try {
            $result = DB::select("SELECT sc.email, st.name FROM suscripciones sc
                        JOIN states st ON sc.stateID = st.id;");

            return $result;

        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
