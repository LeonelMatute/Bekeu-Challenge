<?php

namespace App\repositories;

use Exception;
use Illuminate\Support\Facades\DB;

class statesRepository
{

    public function getStates(){
        try {
                $result = DB::select('SELECT * FROM states');
                return $result;
        }
        catch (Exception $e){
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
