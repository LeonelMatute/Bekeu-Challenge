<?php

namespace App\Http\Controllers;

use App\repositories\statesRepository;
use App\repositories\emailRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EmailController extends Controller
{
    private $statesRepository;
    private $emailRepository;

    public function __construct(statesRepository $statesRepository, emailRepository $emailRepository)
    {
        $this->statesRepository = $statesRepository;
        $this->emailRepository = $emailRepository;
    }

    public function index(){

        return view('welcome', ['respuesta' => $this->statesRepository->getStates()]);
        //return view('pages.index');
    }

    public function save(Request $request){

        $this->emailRepository->saveEmail($request->email,$request->state);

        return view('listado', ['items' => $this->emailRepository->listar()]);
    }

}
