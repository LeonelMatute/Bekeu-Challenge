<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <style>
            button {
                margin: 10px;
                text-align: center;
                background-color: #ECF0F1;
                border: 2px solid transparent;
                border-radius: 3px;
                font-size: 16px;
                font-weight: 200;
                padding: 10px 0;
                width: 250px;
                transition: border .5s;
            }

        </style>
    </head>
    <h1> LISTADO DE EMAILS</h1>
    <table class="pack-table" style="text-align: left">
        <tr>
            <th>Email</th>
            <th>Estado</th>
        </tr>
        @foreach($items as $item)
            <tr>
                <td>{{ $item->email }}</td>
                <td>{{ $item->name }}</td>
            </tr>
        @endforeach
    </table>

    <button style="background-color: black; color: white"><a class="login-link" href="/" style="color: white">Volver</a></button>
</html>
